// @jest-environment node

import { scoreWRBatch } from '../services/rankingsFusionService.v3_2';

const cfg = {
  weights: {
    dynasty: { north: 0.36, east: 0.20, south: 0.28, west: 0.08, prior: 0.08 },
    redraft: { north: 0.48, east: 0.24, south: 0.18, west: 0.10 }
  },
  bounds: {
    north: {min: 0, max: 40},
    east:  {min: 0, max: 100},
    south: {min: 0, max: 100},
    west:  {min: 0, max: 100},
  },
  caps: { west_max: 80, north_rookie_cap: 80, rookie_pre8_weeks_max_rank: 12 }
};

describe('Fusion sanity', () => {
  test('Jefferson should outscore rookie Keon in dynasty', () => {
    const players = [
      {
        id:'jj', name:'Justin Jefferson', pos:'WR', age:25, games_played:80, is_rookie:false,
        xfp_recent: 24.0, xfp_season: 23.0, targets_g: 9.5, tprr_share: 0.30, yprr: 2.8,
        team_proe: 70, qb_stability: 75, role_clarity: 90, scheme_ol: 75,
        injury_risk: 5, volatility: 25,
        adp_rank: 2, model_rank_guess: 2, contract_years: 3, pos_scarcity_z: 0,
        proven_elite: true, prior_score: 92
      },
      {
        id:'kc', name:'Keon Coleman', pos:'WR', age:23, games_played:0, is_rookie:true,
        xfp_recent_proj: 27.15, xfp_season: 0, targets_g: 0, tprr_share: 0.0, yprr: 0.0,
        team_proe: 80, qb_stability: 95, role_clarity: 45, scheme_ol: 75,
        injury_risk: 0, volatility: 30,
        adp_rank: 36, model_rank_guess: 40, contract_years: 4, pos_scarcity_z: 0.2,
        proven_elite: false
      }
    ] as any;

    const res = scoreWRBatch(players, cfg as any, 'dynasty');
    const jj = res.find(x => x.id==='jj')!;
    const kc = res.find(x => x.id==='kc')!;

    expect(jj.score).toBeGreaterThan(kc.score);
    expect(kc.north).toBeLessThanOrEqual(80); // rookie cap pre-sample
  });
});
