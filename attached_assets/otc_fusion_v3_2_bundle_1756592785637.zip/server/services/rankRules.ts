export interface ScoredPlayer { id: string; name: string; pos: string; is_rookie?: boolean; games_played?: number; score: number; }

// Enforce sanity: rookies cannot be ranked above WR12 pre-8 games.
export function enforceRookieCeilingWR(players: ScoredPlayer[]): ScoredPlayer[] {
  const wrs = players.filter(p => p.pos === 'WR');
  const rookies = wrs.filter(p => p.is_rookie && (p.games_played || 0) < 8);
  if (rookies.length === 0) return players;

  // Sort WRs by score desc
  const sortedWR = [...wrs].sort((a,b) => b.score - a.score);
  const cutoffScore = sortedWR[Math.min(11, sortedWR.length-1)]?.score ?? Infinity; // WR12
  const adjusted = new Map<string, number>();

  for (const r of rookies) {
    if (r.score > cutoffScore) {
      adjusted.set(r.id, Math.min(r.score, cutoffScore - 0.1));
    }
  }
  return players.map(p => adjusted.has(p.id) ? ({...p, score: adjusted.get(p.id)!}) : p);
}
