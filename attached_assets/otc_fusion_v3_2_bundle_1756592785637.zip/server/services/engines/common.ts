/* Common utilities for fusion system v3.2 */
export type Num = number;
export const clamp01 = (x: Num) => Math.max(0, Math.min(1, x));
export const safe = (x: any, d: number = 50): number => Number.isFinite(x) ? (x as number) : d;

export function pct(x: Num, min: Num, max: Num): Num {
  if (!Number.isFinite(min) || !Number.isFinite(max) || max <= min) return 50;
  const r = (x - min) / (max - min);
  return Math.max(0, Math.min(100, r * 100));
}

export function shrink(x: number, nSamples: number, prior: number, k: number = 12): number {
  const n = Math.max(0, nSamples || 0);
  const w = n / (n + k);
  return w * x + (1 - w) * prior;
}

export interface Bounds { min: number; max: number; }
export interface BoundsSet {
  north: Bounds; east: Bounds; south: Bounds; west: Bounds;
  prod?: Bounds; opp?: Bounds; // optional legacy
}

export interface PlayerInput {
  id: string;
  name: string;
  pos: 'WR'|'RB'|'TE'|'QB';
  team?: string;
  age?: number;
  games_played?: number;
  is_rookie?: boolean;

  // Production/usage
  xfp_recent_proj?: number;
  xfp_recent?: number;
  xfp_season?: number;
  targets_g?: number;
  tprr_share?: number;
  yprr?: number;

  // Context
  team_proe?: number;
  qb_stability?: number;
  role_clarity?: number;
  scheme_ol?: number;

  // Risk
  age_penalty?: number;
  injury_risk?: number;
  volatility?: number;

  // Market
  adp_rank?: number;
  model_rank_guess?: number; // from previous version or neutral
  contract_years?: number;
  pos_scarcity_z?: number;

  // Priors
  proven_elite?: boolean;
  prior_score?: number; // 0-100, optional

  // For debug
  _debug?: Record<string, any>;
}

export interface Quadrants {
  north: number;
  east: number;
  south: number;
  west: number;
  prior?: number;
}

export interface FusionWeights {
  north: number; east: number; south: number; west: number; prior?: number;
}
