import { Bounds, pct, safe, shrink } from './common';

export function northScoreWR(
  p: {
    xfp_recent_proj?: number; xfp_recent?: number; xfp_season?: number;
    targets_g?: number; tprr_share?: number; yprr?: number;
    is_rookie?: boolean; games_played?: number;
  },
  b: Bounds
): number {
  const league_prior = 14.0; // conservative WR prior xFP
  const n = p.games_played || 0;
  const xfp_recent = Number.isFinite(p.xfp_recent) ? (p.xfp_recent as number) : (p.xfp_recent_proj ?? 0);
  const xfp_recent_shrunk = shrink(xfp_recent, n, league_prior, 12);

  // raw composite
  const comp =
    0.45*safe(xfp_recent_shrunk, NaN) +
    0.25*safe(p.xfp_season, NaN) +
    0.15*safe(p.targets_g, NaN) +
    0.10*safe(p.tprr_share, NaN) +
    0.05*safe(p.yprr, NaN);

  let north = pct(comp, b.min, b.max);

  // Rookie cap pre sample
  if (p.is_rookie && n < 8) {
    north = Math.min(north, 80);
  }
  return north;
}
