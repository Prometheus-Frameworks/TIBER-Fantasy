import { Bounds, pct, safe } from './common';

export function dynAgePenalty(age: number|undefined, position: string): number {
  const curves: Record<string, { peak: number; slope: number }> = {
    QB: { peak: 28, slope: 0.8 },
    RB: { peak: 25, slope: 2.2 },
    WR: { peak: 26, slope: 1.6 },
    TE: { peak: 27, slope: 1.2 },
  };
  const a = Number.isFinite(age) ? (age as number) : 26;
  const curve = curves[position] || curves.WR;
  return Math.max(0, (a - curve.peak) * curve.slope);
}

export function southSafetyScore(
  p: { age?: number; pos: string; injury_risk?: number; volatility?: number; is_rookie?: boolean; games_played?: number; },
  b: Bounds,
  mode: 'dynasty'|'redraft'
): number {
  const age_pen = dynAgePenalty(p.age, p.pos) * (mode === 'dynasty' ? 1.3 : 0.6);
  const inj = safe(p.injury_risk, 10);
  const vol = safe(p.volatility, 15);
  const rookie_unc = (p.is_rookie ? 18 : 0) + ((p.games_played||0) < 8 ? 10 : 0);

  const risk_comp = 0.55*age_pen + 0.30*inj + 0.15*vol + (mode==='dynasty' ? 0.35*rookie_unc : 0);
  const risk_pct = pct(risk_comp, b.min, b.max);
  return Math.max(0, 100 - risk_pct);
}
