import { Bounds, pct, safe } from './common';

export function eastScoreWR(
  p: { team_proe?: number; qb_stability?: number; scheme_ol?: number; role_clarity?: number; is_rookie?: boolean; },
  b: Bounds
): number {
  const comp =
    0.30*safe(p.team_proe, NaN) +
    0.25*safe(p.qb_stability, NaN) +
    0.20*safe(p.scheme_ol, NaN) +
    0.25*safe(p.role_clarity, NaN);

  let east = pct(comp, b.min, b.max);

  // If role is unclear and rookie, cap East to avoid QB pass-through
  if (p.is_rookie && safe(p.role_clarity, 40) < 60) {
    east = Math.min(east, 70);
  }
  return east;
}
