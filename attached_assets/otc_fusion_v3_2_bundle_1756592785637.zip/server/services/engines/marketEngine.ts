import { Bounds, pct, safe } from './common';

export function westScore(
  p: { adp_rank?: number; model_rank_guess?: number; contract_years?: number; pos_scarcity_z?: number; },
  b: Bounds,
  mode: 'dynasty'|'redraft',
  westCap: number = 80
): number {
  const adp = safe(p.adp_rank, NaN);
  const model = safe(p.model_rank_guess, NaN);

  // Efficiency: undervaluation should increase score (we want bargains)
  // price_gap = model - adp; negative => undervalued (better for us)
  let eff_raw = Number.isFinite(adp) && Number.isFinite(model) ? (-(model - adp)) : 0; 
  // Bound to +/-20 ranks
  eff_raw = Math.max(-20, Math.min(20, eff_raw));
  const market_eff = 50 + (eff_raw * 2); // 10 ranks cheap => +20 points above neutral 50

  const contract = safe(p.contract_years, 0);
  const contract_norm = Math.min(100, Math.max(0, (contract / 4) * 100)); // 0-4 yrs → 0-100

  const scarcityZ = safe(p.pos_scarcity_z, 0);
  const scarcity_norm = Math.max(0, Math.min(100, 50 + (scarcityZ * 20))); // crude z→0-100

  const comp =
    0.50*market_eff +
    0.30*contract_norm*(mode==='dynasty' ? 1.1 : 0.9) +
    0.20*scarcity_norm;

  return Math.min(westCap, pct(comp, b.min, b.max));
}
