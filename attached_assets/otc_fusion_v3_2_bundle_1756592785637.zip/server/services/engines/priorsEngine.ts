import { safe } from './common';

export function priorScoreWR(p: { proven_elite?: boolean; prior_score?: number; }): number {
  if (Number.isFinite(p.prior_score)) return p.prior_score as number;
  if (p.proven_elite) return 92; // Jefferson/Chase archetype
  return 50; // neutral prior
}
