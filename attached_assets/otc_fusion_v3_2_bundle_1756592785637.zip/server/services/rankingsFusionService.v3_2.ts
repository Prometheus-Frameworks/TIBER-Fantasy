import { BoundsSet, FusionWeights, PlayerInput, Quadrants, safe } from './engines/common';
import { northScoreWR } from './engines/northEngine';
import { eastScoreWR } from './engines/eastEngine';
import { southSafetyScore } from './engines/riskEngine';
import { westScore } from './engines/marketEngine';
import { priorScoreWR } from './engines/priorsEngine';
import { enforceRookieCeilingWR } from './rankRules';

export interface FusionConfig {
  weights: { dynasty: FusionWeights; redraft: FusionWeights };
  bounds: BoundsSet;
  caps: { west_max: number; north_rookie_cap: number; rookie_pre8_weeks_max_rank: number };
}

export interface ScoredOut {
  id: string; name: string; pos: string;
  north: number; east: number; south: number; west: number; prior?: number;
  score: number; // 0-100
}

export function fuseScore(q: Quadrants, w: FusionWeights): number {
  const num = (w.north*safe(q.north)) + (w.east*safe(q.east)) + (w.south*safe(q.south)) + (w.west*safe(q.west)) + ((w.prior||0)*safe(q.prior,50));
  const den = w.north + w.east + w.south + w.west + (w.prior||0);
  return den > 0 ? Math.round((num/den) * 10) / 10 : 50;
}

// Compute bounds from raw comps if needed
export function computeSimpleBounds(players: PlayerInput[], extractor: (p: PlayerInput)=>number): {min:number,max:number} {
  const vals = players.map(extractor).filter(v => Number.isFinite(v)) as number[];
  if (vals.length === 0) return {min:0,max:1};
  const min = Math.min(...vals);
  const max = Math.max(...vals);
  return {min,max: (max===min? min+1 : max)};
}

export function scoreWRBatch(
  players: PlayerInput[],
  cfg: FusionConfig,
  mode: 'dynasty'|'redraft'
): ScoredOut[] {
  // If bounds are not provided, compute naive bounds from composites
  const b = cfg.bounds;

  const out: ScoredOut[] = players.map(p => {
    const q_north = northScoreWR(p, b.north);
    const q_east  = eastScoreWR(p, b.east);
    const q_south = southSafetyScore({age:p.age, pos:p.pos, injury_risk:p.injury_risk, volatility:p.volatility, is_rookie:p.is_rookie, games_played:p.games_played}, b.south, mode);
    const q_west  = westScore({adp_rank:p.adp_rank, model_rank_guess:p.model_rank_guess, contract_years:p.contract_years, pos_scarcity_z:p.pos_scarcity_z}, b.west, mode, cfg.caps.west_max);
    const q_prior = priorScoreWR({proven_elite:p.proven_elite, prior_score:p.prior_score});

    const q: Quadrants = { north: q_north, east: q_east, south: q_south, west: q_west, prior: (mode==='dynasty'? q_prior : undefined) };
    const score = fuseScore(q, cfg.weights[mode]);

    return { id: p.id, name: p.name, pos: p.pos, north: q_north, east: q_east, south: q_south, west: q_west, prior: q_prior, score };
  });

  // Rookie ceiling enforcement (dynasty only)
  const enforced = mode==='dynasty' ? enforceRookieCeilingWR(out) : out;
  return enforced;
}
