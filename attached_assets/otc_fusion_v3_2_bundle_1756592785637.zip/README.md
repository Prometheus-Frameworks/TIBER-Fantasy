# OTC Fusion v3.2 Patch (DeepSeek x Compass)

## What this is
Production-ready drop-ins to fix the Keon > Jefferson bug by:
- Shrinking rookie projections
- Correcting Market Efficiency (no hype 100s)
- Adding rookie uncertainty to Risk
- Adding proven-elite priors & floors
- Removing WR FPTS hard override sorts
- Enforcing a rookie ceiling pre-8 games

## Files
- config/fusionWeights.v3.2.json
- server/services/engines/common.ts
- server/services/engines/northEngine.ts
- server/services/engines/eastEngine.ts
- server/services/engines/riskEngine.ts
- server/services/engines/marketEngine.ts
- server/services/engines/priorsEngine.ts
- server/services/rankRules.ts
- server/services/rankingsFusionService.v3_2.ts
- server/tests/fusion.sanity.test.ts
- server/patches/removeWRFPTSOverride.diff

## How to wire it
1) **Kill the WR FPTS override** per `server/patches/removeWRFPTSOverride.diff`.
2) Import `scoreWRBatch` from `rankingsFusionService.v3_2.ts` in your rankings route.
3) Provide your normalized players (Sleeper feed) to `scoreWRBatch(players, cfg, mode)`.
   - `cfg` = load from `config/fusionWeights.v3.2.json` and your bounds (0–100 works; or compute from population).
4) For dynasty, pass `proven_elite: true` / `prior_score` for guys like Jefferson/Chase (optional but recommended).
5) Sort final results by `score` desc. Emit `north/east/south/west/prior` for debug.

## Quick test
Run Jest on `server/tests/fusion.sanity.test.ts`.
It asserts Jefferson > Keon and caps rookie North pre-sample.

## Notes
- West is capped at 80 and contributes less to dynasty.
- East defers to `role_clarity`, capping rookies at 70 if unclear.
- South adds explicit rookie/low-sample uncertainty (dynasty only).
- North uses shrinkage so projections don't bulldoze veterans.

Ship it.
